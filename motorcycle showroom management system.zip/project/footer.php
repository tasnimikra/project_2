<div class="footer">
    <h6>Copyright © 2019, Stallions Inc.</h6>
    <h6><font size="3%">Brought to you by:<br>
    Sabrina Alam, Dept. of CSE, EWU</font></h6>

</div>