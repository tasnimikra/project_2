<!DOCTYPE html>
<html lang="en">
<head>
	<title>Remove User</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/png" href="images/icon-red.png"/>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="css/fonts.css">
	<link rel="stylesheet" type="text/css" href="css/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="css/form.css">
	<link rel="stylesheet" type="text/css" href="css/short.css">
    <link rel="stylesheet" type="text/css" href="css/fontawesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/all.min.css">
	<style> .error {color: #FF0000;} </style>

</head>
<body>

<?php
include_once('validation.php');
session_start();
?>
	


	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/stallion.jpg');">
			
			<div class="wrap-login100 p-t-30 p-b-50">
				<span class="login100-form-title p-b-41">
				<img src="images/icon-violet.png" alt="Logo" width=80px><br>
					Remove User
				</span>
				
				<?php
                    
                    if (isset($_GET['currentPass'])){
                        currentPass();
                    }

                    if (isset($_GET['remove'])){
                        remove();
                    }

                    if(isset($_GET['unsucMessage'])){
                        echo '<div style="text-align:center;">';
                        unsucMessage();
                        echo '</div>';
                    }

                    if(isset($_GET['failMessage'])){
                        echo '<div style="text-align:center;">';
                        failMessage();
                        echo '</div>';
                    }
                    
				?>                  

                    
			</div>
		</div>
	</div>	

	<div id="dropDownSelect1"></div>

	<?php

    function currentPass(){
       
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $db = mysqli_connect(dbhost,dbuser,dbpass,database);

            $username = $_SESSION['username'];
            $password = mysqli_real_escape_string($db,$_POST['pass']);
            
            $sql = "SELECT user_name FROM users WHERE user_name = '$username' and password = '$password'";
            $result = mysqli_query($db,$sql);
            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

            $count = mysqli_num_rows($result);

            if($count == 1) {
                header('location:remove_user.php?remove');
            } else {
                
                echo '<div style="text-align:center;">';
                failMessage();
                echo '</div>';
            }
        }

        echo '<form class="login100-form p-b-33 p-t-5" method="post" action="remove_user.php?currentPass">';

		echo '<div style="text-align:right; padding-right:15px">
						<span class="error">* Required Field</span>
                    </div>';

        echo '<div class="wrap-input100">
                    <input class="input100" type="password" name="pass" placeholder="Enter Password">
                    <span class="focus-input100" data-placeholder="&#xe60b;"></span>
                    <div style="text-align:right; padding-right:15px">
                        <span class="error">*</span>
                    </div>
                </div>';

        echo '<div class="container-login100-form-btn m-t-32">
                <input class="login100-form-btn active" type="submit" value="NEXT">
                <a class="login100-form-btn" href="'.$_SESSION['url'].'">
                    Back
                </a>
            </div>';

        echo '</form>';   

    }

    function remove(){
        
        $uid = $uidErr = "";
                        
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    
            if(empty($_POST["user_id"])){
                $uidErr = "User is required";
            } else if(!is_numeric($_POST["user_id"])){
                $uidErr = "User is required";
                $uid = "";
            } else {
                $uid = test_input($_POST["user_id"]);
            }

            $db = mysqli_connect(dbhost,dbuser,dbpass,database);

            $sql = "DELETE FROM users WHERE user_id = $uid";
            $sql2 = "DELETE FROM user_info WHERE user_id = $uid";
        
        if($uid != "" && $_SESSION['logged'] && $_SESSION['user_type']=='Admin'){
            if(mysqli_query($db,$sql)) {
            
                mysqli_query($db,$sql2);
                header('location:users.php?remMessage');
            } else {
                unsucMessage();
            }
            mysqli_close($db);
        } else {
            unsucMessage();
        }
    }
        
        echo '<form class="login100-form p-b-33 p-t-5" method="post" action="remove_user.php?remove">';

        echo '<div style="text-align:right; padding-right:15px">
						<span class="error">* Required Field</span>
                    </div>';
        
        echo         '<div class="wrap-input100">
                    <select class="input100" name="user_id">
                        <option hidden>Select User</option>';

                            $db = mysqli_connect(dbhost,dbuser,dbpass,database);
                            $username = $_SESSION['username'];
                            
                            $sql = "SELECT user_id, user_name FROM users where user_name!='$username'";

                            if($result = mysqli_query($db, $sql)){
                                if(mysqli_num_rows($result) > 0){
                                    while($row = mysqli_fetch_array($result)){
                                            $uid = $row['user_id'] ;
                                            $uname = $row['user_name'];
                                            echo '<option value='.$uid.'>'.$uname.'</option>';
                                    }
                                    mysqli_free_result($result);
                                } else{
                                    echo '<div class="container">';
                                    echo '<div class="alert alert-warning" style="text-align:center;">';
                                    echo "No records found";
                                    echo '</div></div>';
                                }
                            } else{
                                echo "ERROR: Could not able to execute $sql. " . mysqli_error($db);
                            }
                            mysqli_close($db);
                
                echo    '</select>';	
                echo    '<span class="focus-input100" data-placeholder="&#xe60b;"></span>
                    <div style="text-align:right; padding-right:15px">
                        <span class="error">* </span>
                    </div>
                </div>';

         echo '<div class="container-login100-form-btn m-t-32">
                    <input class="login100-form-btn active" type="submit" value="Remove">
                    <a class="login100-form-btn" href="'.$_SESSION['url'].'">
                        Back
                    </a>
                </div>';

        echo '</form>'; 
    }

	function failMessage(){
		echo '<div class="alert alert-danger">';
		echo '<strong>Incorrect Password</strong>';
		echo '</div>';
    }
    
    function unsucMessage(){
		echo '<div class="alert alert-danger">';
		echo '<strong>Attemt Unsuccessful!!</strong>';
		echo '</div>';
	}

	?>
	
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/form.js"></script>
    <script src="js/fontawesome.min.js"></script>
    <script src="js/all.min.js"></script>

</body>
</html>